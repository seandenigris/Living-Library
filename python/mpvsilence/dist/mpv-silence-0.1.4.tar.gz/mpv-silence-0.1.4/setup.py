from setuptools import setup
setup(
    name="mpv-silence",
    version="0.1.4",
    py_modules=['mpvsilence'],
    install_requires=['mpv']
)
